﻿
using var game = new Intro_Graphics.Sprint_0();
game.Run();
